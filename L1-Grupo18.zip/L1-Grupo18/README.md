# Tarea 1 - Redes de Computadores

Integrantes:
    * Miguel Soto           Rol: 201973623-K
    * Joaquin Contreras     Rol: 201973527-6
Grupo: 18

## Ejecucion

Para poder hacer funcionar el juego correctamente, se
deben correr los siguientes comandos en terminales
separados:

```
python server.py
go run conecta4.go
python client.py
```

## Análisis

El análisis del programa esta es un archivo llamdo
_analysis.pdf_.


